// Small client script
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('contactForm');
if (form) {
  form.addEventListener('submit', (e) => {
    const responseEl = document.getElementById('formResponse');
    // Let the browser handle submission to contact.php.
    responseEl.textContent = 'Sending...';
    // We'll let the server respond by redirect or message; this is just UX.
    setTimeout(()=> responseEl.textContent = '', 2000);
  });
}