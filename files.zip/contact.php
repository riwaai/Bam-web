<?php
// Simple contact handler.
// IMPORTANT: Edit $EMAIL_TO to your destination email.
$EMAIL_TO = 'you@example.com'; // <-- replace this

// Basic validation
$name = isset($_POST['name']) ? trim($_POST['name']) : '';
$email = isset($_POST['email']) ? trim($_POST['email']) : '';
$message = isset($_POST['message']) ? trim($_POST['message']) : '';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo "Method not allowed.";
    exit;
}

if (!$name || !$email || !$message) {
    http_response_code(400);
    echo "Please fill all required fields.";
    exit;
}

// Basic email headers
$subject = "Website contact from: " . substr($name,0,80);
$body = "Name: $name\nEmail: $email\n\nMessage:\n$message\n";
$headers = "From: $name <$email>\r\nReply-To: $email\r\n";

// Try to send
$ok = false;
if (function_exists('mail')) {
    $ok = mail($EMAIL_TO, $subject, $body, $headers);
}

// If mail() is not available or failed, return helpful message
if ($ok) {
    // Redirect back with success message (simple)
    header("Location: /?sent=1");
    exit;
} else {
    http_response_code(500);
    echo "Failed to send message. If your host requires SMTP authentication, configure SMTP (PHPMailer) and update this file.";
    exit;
}
?>