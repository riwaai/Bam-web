#!/usr/bin/env bash
# Creates a zip named site.zip excluding node_modules and .git
zip -r site.zip . -x "node_modules/*" ".git/*" "*.zip" "*.DS_Store"
echo "Created site.zip — upload this to Hostinger File Manager and extract into public_html."