# Simple Website Repo — Ready to Upload to Hostinger

This repository is a small, production-ready static website with a PHP contact endpoint that is Hostinger-friendly.

Contents
- `index.html` — main site (responsive)
- `css/styles.css` — styles
- `js/app.js` — small JS for interaction
- `contact.php` — PHP handler for contact form (configure EMAIL_TO)
- `.htaccess` — good defaults (force HTTPS, pretty URLs)
- `package.json` — optional local dev scripts
- `deploy.sh` — helper to create zip for upload

Before deploying
1. Edit `index.html` and `css/styles.css` to match your branding and content.
2. Open `contact.php` and set `$EMAIL_TO` to the address that should receive contact form messages. If Hostinger requires SMTP, see notes below.

Local testing
- For a static preview: open `index.html` in the browser.
- For testing PHP locally (recommended if using `contact.php`):
  - Run: `php -S localhost:8000`
  - Open: http://localhost:8000

How to push to GitHub (optional)
1. Create a GitHub repo (via github.com).
2. In your project folder:
   - `git init`
   - `git add .`
   - `git commit -m "Initial commit"`
   - `git branch -M main`
   - `git remote add origin https://github.com/<your-user>/<repo>.git`
   - `git push -u origin main`

Upload / Deploy to Hostinger — three options

Option A — Upload zip via Hostinger File Manager (easiest)
1. Compress your project folder to `site.zip` (or use `./deploy.sh` which creates `site.zip`).
2. In Hostinger hPanel → Files → File Manager:
   - Go to the domain's `public_html` (or the domain directory).
   - Upload `site.zip`.
   - Extract files. Make sure `index.html` is in `public_html/`.
3. If using `contact.php`, make sure extracted files are in the same folder and PHP is supported (Hostinger supports PHP by default).
4. Visit your domain.

Option B — Upload via FTP / SFTP (recommended for iterative work)
1. In Hostinger hPanel → FTP Accounts, create an FTP or SFTP account if you don't have one.
2. Use FileZilla (or your client) to connect (host, username, password, port).
3. Upload all files to `public_html` (or the domain folder).
4. Set correct permissions (files 644, folders 755). Contact PHP will work as long as uploaded to `public_html`.

Option C — Deploy via Git (if your Hostinger plan supports Git)
1. Push your repo to GitHub (see above).
2. In Hostinger hPanel, look for "Git" or "SSH" deployment features; you can often:
   - Create a Git repository or set up deployment to pull from your GitHub repo.
   - Provide repository URL and branch (e.g., main).
   - Set destination directory (`public_html`).
3. Trigger deploy/pull from the hPanel UI or via SSH.

Domain & SSL
- In hPanel → Domains, point your domain's DNS to Hostinger nameservers.
- In hPanel → SSL, enable Let's Encrypt SSL for the domain (free button usually available).
- Optionally enable "Force HTTPS" via `.htaccess` (this repo already includes a rule).

Configuring the contact form (contact.php)
- Edit `contact.php` and set `$EMAIL_TO` to the destination address.
- Hostinger usually supports `mail()`; if it doesn't, configure SMTP using Hostinger SMTP credentials (they provide SMTP server, user, pass) and use PHPMailer. If you need that, I can add a PHPMailer example.

Testing & troubleshooting
- If contact messages don't arrive: check spam, check Hostinger mail logs, or switch to SMTP with authenticated credentials.
- If you see 500 errors: check PHP error logs in hPanel (or enable display_errors temporarily in php.ini).
- If pages not showing: ensure index.html is in `public_html` and file permissions are correct.

Need me to:
- customize this template with your logo/text,
- add SMTP (PHPMailer) contact handling,
- convert to a Node/Express app, WordPress, or another stack?

I can also create the GitHub repo for you if you provide your GitHub repo name and confirm you want me to do that.